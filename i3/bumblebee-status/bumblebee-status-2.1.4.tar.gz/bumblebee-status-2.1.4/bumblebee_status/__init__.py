import bumblebee_status.discover

bumblebee_status.discover.discover()
